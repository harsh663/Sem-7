typedef struct
{
    char username[30];
    unsigned char password[30];
    char name[30];
    int age;
} UserData;
typedef struct
{
    char username[30];
    unsigned char password[30];
} UserLoginData;
